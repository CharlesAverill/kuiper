from sqlalchemy.ext.declarative import declarative_base

#: SQLAlchemy declarative base class.
Base = declarative_base()
